-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: narkoba
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gejala`
--

DROP TABLE IF EXISTS `gejala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gejala` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kelompok_gejala_id` int(11) NOT NULL,
  `kode` varchar(5) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kelompok_gejala_id` (`kelompok_gejala_id`),
  CONSTRAINT `gejala_ibfk_1` FOREIGN KEY (`kelompok_gejala_id`) REFERENCES `kelompok_gejala` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gejala`
--

LOCK TABLES `gejala` WRITE;
/*!40000 ALTER TABLE `gejala` DISABLE KEYS */;
INSERT INTO `gejala` VALUES (16,1,'GU','Apakah anda pernah menggunakan narkoba selama 3 kali ?'),(17,1,'G1','Lebih akfit melakukan semua kegiatan dimalam hari ?'),(18,1,'G2','Menimbulkan keinginan untuk menyibukan di tetapi dalam keadaan tidak berkosentrasi sehingga bersikap gelisah dan linglung.'),(19,1,'G3','Mengalami perubahan emosional.'),(20,1,'G4','TImbul gangguan saat tidur.'),(21,1,'G5','Kesulitan kinerja yang mmebutuhkan konsentrasi'),(22,1,'G6','Mulai mengalami penurunan berat badan disaat atau sesudah menggunakan narkoba.'),(23,1,'G7','Mulai mengalami kesulitan bernafas.'),(24,1,'G8','Mulai mengalami gangguan pengelihatan.'),(25,1,'G9','Mual dan muntah terjadi saat pengaruh obat masih tersisa dalam tubuh selama 3 hari sejak pemakaian.'),(26,1,'G10','Merasa pusing disaat atau sesudah mengkonsumsi narkoba.'),(28,1,'G11','Tidak berkeinginan untuk berkerja ataupun hal lain yang lebih bermanfaat.'),(29,1,'G12','Timbul masalah kulit dan sekitar mulut , hidung dan perubahan warna muka.'),(30,1,'G13','Mata selalu merah , gatal dan gangguan pengelihatan setelah memakai dan dalam pengaruh narkoba.'),(31,1,'G14','Timbul gejala radang paru-paru.'),(32,1,'G15','Timbulnya gejala kerusakan hati , lambung , dan ginjal.'),(33,1,'G16','Pingsan sering terjadi disaat pengguna berkeinginan unutk mengkonsumsi narkoba.'),(34,1,'G17','Tingkat emosional yang berlebihan.'),(35,1,'G18','Penurunan berat badan yang berlebihan.'),(36,1,'G19','Terjadi kerusakan sistem syaraf otak sehingga mengalami ketidakmampuan berkomunikasi dan tidak mampu melakukan gerakan secara motorik.');
/*!40000 ALTER TABLE `gejala` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gejala_narkoba`
--

DROP TABLE IF EXISTS `gejala_narkoba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gejala_narkoba` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gejala_id` int(11) NOT NULL,
  `narkoba_id` int(11) NOT NULL,
  `md` float NOT NULL,
  `mb` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gejala_id` (`gejala_id`),
  KEY `penyakit_id` (`narkoba_id`),
  CONSTRAINT `gejala_narkoba_ibfk_1` FOREIGN KEY (`gejala_id`) REFERENCES `gejala` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gejala_narkoba_ibfk_2` FOREIGN KEY (`narkoba_id`) REFERENCES `narkoba` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gejala_narkoba`
--

LOCK TABLES `gejala_narkoba` WRITE;
/*!40000 ALTER TABLE `gejala_narkoba` DISABLE KEYS */;
INSERT INTO `gejala_narkoba` VALUES (31,16,8,0.1,0.6),(32,17,7,0.62,0.65),(33,18,8,0.7,0.75),(34,19,8,0.7,0.75),(35,20,8,0.69,0.75),(36,21,9,0.74,0.8),(37,22,9,0.77,0.85),(38,23,9,0.7,0.8),(39,24,9,0.7,0.8),(40,25,9,0.7,0.8),(41,26,9,0.8,0.9),(42,28,9,0.79,0.89),(43,29,9,0.81,0.92),(44,30,9,0.78,0.8),(45,31,9,0.83,0.95),(46,32,9,0.83,0.95),(47,33,9,0.76,0.9),(48,34,9,0.73,0.88),(49,35,9,0.73,0.88),(50,36,9,0.73,0.88);
/*!40000 ALTER TABLE `gejala_narkoba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelompok_gejala`
--

DROP TABLE IF EXISTS `kelompok_gejala`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kelompok_gejala` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelompok_gejala`
--

LOCK TABLES `kelompok_gejala` WRITE;
/*!40000 ALTER TABLE `kelompok_gejala` DISABLE KEYS */;
INSERT INTO `kelompok_gejala` VALUES (1,'Gejala','-');
/*!40000 ALTER TABLE `kelompok_gejala` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `narkoba`
--

DROP TABLE IF EXISTS `narkoba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `narkoba` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `narkoba`
--

LOCK TABLES `narkoba` WRITE;
/*!40000 ALTER TABLE `narkoba` DISABLE KEYS */;
INSERT INTO `narkoba` VALUES (7,'D1','Tidak Kecanduan','Anda terdeteksi sistem kami dan dinyatakan tidak kecanduan.'),(8,'D2','Coba-coba','Anda terdeteksi sistem kami dan dinyatakan masih coba-coba.'),(9,'D3','Kecanduan','Anda terdeteksi sistem kami dan dinyatakan sudah kecanduan dan disarankan untuk segera melakukan rehabilitasi.');
/*!40000 ALTER TABLE `narkoba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','Fadilah Riczky');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'narkoba'
--

--
-- Dumping routines for database 'narkoba'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-17  6:06:06
